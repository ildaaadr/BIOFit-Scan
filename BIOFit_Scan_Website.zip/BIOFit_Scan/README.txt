BIOFit Scan
===========

File:
- index.html
- style.css
- script.js
- images/ (masukkan 6 poster kamu)

Nama file poster yang diharapkan:
1. treadmill.jpg
2. sepeda-statis.jpg
3. mesin-eliptis.jpg
4. lat-pulldown.jpg
5. seated-row.jpg
6. rowing-machine.jpg

Cara menjalankan:
1. Ekstrak ZIP.
2. Masukkan poster ke folder images/ dan samakan nama file.
3. Buka index.html di browser untuk uji coba.
4. Untuk online, upload folder ini ke layanan hosting statis seperti GitHub Pages atau Netlify.
5. URL hasil hosting dapat dijadikan tujuan QR Code masing-masing alat.

Catatan:
Google Sites tidak berfungsi sebagai hosting HTML/CSS/JS penuh. Untuk versi coding penuh, gunakan hosting statis, lalu tautkan/sematkan dari Google Sites jika diperlukan.
