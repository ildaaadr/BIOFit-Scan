const equipment = [
  {
    id:"treadmill", name:"Treadmill", category:"cardio", label:"CARDIO", icon:"🏃",
    description:"Latihan berjalan atau berlari untuk mendukung kebugaran kardiorespirasi.",
    poster:"images/treadmill.jpg",
    guide:["Berdiri di sisi treadmill sebelum menyalakan alat.","Mulai dengan kecepatan rendah sesuai kemampuan.","Pertahankan postur tubuh tetap tegak dan pandangan ke depan.","Turunkan kecepatan secara bertahap sebelum turun dari alat."],
    muscles:["Quadriceps","Hamstrings","Gluteus","Betis","Core"],
    benefits:["Meningkatkan kebugaran kardiorespirasi","Melatih daya tahan otot kaki","Mendukung kemampuan berjalan dan berlari","Meningkatkan pengeluaran energi selama aktivitas"],
    warning:"Jangan turun ketika belt masih bergerak."
  },
  {
    id:"sepeda", name:"Sepeda Statis", category:"cardio", label:"CARDIO", icon:"🚴",
    description:"Latihan mengayuh untuk melatih kebugaran kardiorespirasi dan daya tahan otot kaki.",
    poster:"images/sepeda-statis.jpg",
    guide:["Atur ketinggian sadel agar posisi kaki nyaman.","Pilih resistensi ringan sesuai kemampuan.","Kayuh secara stabil dan tingkatkan intensitas secara bertahap.","Kurangi kecepatan dan pastikan pedal berhenti sebelum turun."],
    muscles:["Quadriceps","Hamstrings","Gluteus","Betis","Core"],
    benefits:["Meningkatkan kebugaran kardiorespirasi","Melatih daya tahan otot kaki","Mendukung kemampuan bersepeda","Meningkatkan pengeluaran energi selama latihan"],
    warning:"Pastikan posisi sadel dan kaki aman sebelum mulai."
  },
  {
    id:"eliptis", name:"Mesin Eliptis", category:"cardio", label:"CARDIO", icon:"🏃‍♀️",
    description:"Latihan kardiorespirasi dengan pola gerak elips yang melibatkan tubuh bagian bawah dan, saat handle digunakan aktif, tubuh bagian atas.",
    poster:"images/mesin-eliptis.jpg",
    guide:["Pegang handle dan letakkan kedua kaki pada pedal.","Pilih resistensi sesuai kemampuan.","Gerakkan pedal secara stabil dengan postur tegak.","Kurangi kecepatan dan pastikan pedal berhenti sebelum turun."],
    muscles:["Quadriceps","Hamstrings","Gluteus","Betis","Core","Biceps & Triceps"],
    benefits:["Meningkatkan kebugaran kardiorespirasi","Melatih daya tahan otot kaki","Dapat melibatkan tubuh bagian atas saat handle digerakkan","Mendukung aktivitas fisik rutin"],
    warning:"Gunakan handle untuk menjaga keseimbangan saat naik dan turun."
  },
  {
    id:"latpulldown", name:"Lat Pulldown", category:"strength", label:"STRENGTH", icon:"🏋️",
    description:"Latihan tarikan untuk melatih terutama otot punggung dan otot lengan.",
    poster:"images/lat-pulldown.jpg",
    guide:["Duduk dan atur bantalan paha agar tubuh stabil.","Pegang bar sedikit lebih lebar dari bahu.","Tarik bar menuju bagian atas atau tengah dada sambil mengarahkan siku ke bawah.","Kembalikan bar secara perlahan dan terkontrol."],
    muscles:["Latissimus Dorsi","Biceps","Trapezius","Rhomboids","Forearms"],
    benefits:["Meningkatkan kekuatan otot punggung","Melatih kekuatan otot lengan","Mendukung kemampuan gerakan menarik","Meningkatkan kekuatan dan daya tahan otot"],
    warning:"Hindari mengayunkan tubuh dan menarik bar ke belakang kepala."
  },
  {
    id:"seatedrow", name:"Seated Row", category:"strength", label:"STRENGTH", icon:"🏋️",
    description:"Latihan tarikan horizontal yang menargetkan otot punggung dengan bantuan otot lengan.",
    poster:"images/seated-row.jpg",
    guide:["Duduk tegak dan posisikan kaki pada pijakan.","Pegang handle dengan kedua tangan.","Tarik handle ke arah tubuh sambil mengarahkan siku ke belakang.","Kembalikan handle secara perlahan tanpa melepas beban tiba-tiba."],
    muscles:["Latissimus Dorsi","Rhomboids","Trapezius","Biceps","Forearms","Core"],
    benefits:["Memperkuat otot punggung","Melatih kekuatan lengan","Mendukung stabilitas tubuh bagian atas","Mendukung kemampuan gerakan menarik"],
    warning:"Jaga punggung tetap stabil dan hindari mengayunkan tubuh."
  },
  {
    id:"rowing", name:"Rowing Machine", category:"fullbody", label:"FULL BODY", icon:"🚣",
    description:"Latihan dayung yang menggabungkan dorongan kaki dengan tarikan tubuh bagian atas.",
    poster:"images/rowing-machine.jpg",
    guide:["Duduk, pasang kaki pada pijakan, dan pegang handle.","Dorong pijakan menggunakan kaki terlebih dahulu.","Setelah kaki hampir lurus, tarik handle ke arah perut atau dada.","Kembali dengan urutan lengan → tubuh → kaki secara terkontrol."],
    muscles:["Quadriceps","Hamstrings","Gluteus","Latissimus Dorsi","Biceps","Trapezius","Rhomboids","Core"],
    benefits:["Meningkatkan kebugaran kardiorespirasi","Melatih otot kaki","Melatih punggung dan lengan","Melatih koordinasi gerakan tubuh","Meningkatkan pengeluaran energi"],
    warning:"Pertahankan urutan gerakan: Kaki → Tubuh → Lengan saat menarik."
  }
];

const grid = document.getElementById("equipmentGrid");
const searchInput = document.getElementById("searchInput");
const detailSection = document.getElementById("detail");
const detailContent = document.getElementById("detailContent");
const backButton = document.getElementById("backButton");
let activeFilter = "all";

function renderCards(){
  const q = searchInput.value.toLowerCase().trim();
  const list = equipment.filter(e =>
    (activeFilter==="all" || e.category===activeFilter) &&
    (e.name.toLowerCase().includes(q) || e.label.toLowerCase().includes(q))
  );
  grid.innerHTML = list.map(e=>`
    <article class="card">
      <div class="card-img">
        <img src="${e.poster}" alt="Poster ${e.name}" onerror="this.style.display='none';this.parentElement.innerHTML='<span>${e.icon}</span>'">
      </div>
      <div class="card-body">
        <span class="pill">${e.label}</span>
        <h3>${e.name}</h3>
        <p>${e.description}</p>
        <button onclick="openEquipment('${e.id}')">Lihat Panduan →</button>
      </div>
    </article>
  `).join("") || `<p>Alat tidak ditemukan.</p>`;
}

function openEquipment(id){
  const e = equipment.find(item=>item.id===id);
  if(!e) return;
  detailContent.innerHTML = `
    <div class="detail-hero">
      <div>
        <img class="poster" src="${e.poster}" alt="Poster ${e.name}"
          onerror="this.outerHTML='<div class=&quot;poster-placeholder&quot;>Tempat poster ${e.name}<br><small>Masukkan file ke folder images/ dengan nama yang sesuai.</small></div>'">
      </div>
      <div class="detail">
        <p class="eyebrow">${e.label}</p>
        <h1>${e.name}</h1>
        <p class="detail-intro">${e.description}</p>
        <div class="info-grid">
          <div class="info-box"><h3>📖 Panduan Penggunaan</h3><ol>${e.guide.map(x=>`<li>${x}</li>`).join("")}</ol></div>
          <div class="info-box"><h3>💪 Otot yang Bekerja</h3><ul>${e.muscles.map(x=>`<li>${x}</li>`).join("")}</ul></div>
          <div class="info-box"><h3>❤️ Manfaat bagi Tubuh</h3><ul>${e.benefits.map(x=>`<li>${x}</li>`).join("")}</ul></div>
          <div class="info-box"><h3>⚠️ Perhatian</h3><p>${e.warning}</p></div>
        </div>
      </div>
    </div>`;
  document.querySelector("#alat").classList.add("hidden");
  document.querySelector("#tentang").classList.add("hidden");
  detailSection.classList.remove("hidden");
  detailSection.scrollIntoView({behavior:"smooth"});
  history.replaceState(null,"",`#${e.id}`);
}

backButton.addEventListener("click",()=>{
  detailSection.classList.add("hidden");
  document.querySelector("#alat").classList.remove("hidden");
  document.querySelector("#tentang").classList.remove("hidden");
  location.hash="alat";
  window.scrollTo({top:document.querySelector("#alat").offsetTop-70,behavior:"smooth"});
});
searchInput.addEventListener("input",renderCards);
document.querySelectorAll(".filter").forEach(btn=>{
  btn.addEventListener("click",()=>{
    document.querySelectorAll(".filter").forEach(b=>b.classList.remove("active"));
    btn.classList.add("active");
    activeFilter=btn.dataset.filter;
    renderCards();
  });
});
renderCards();
